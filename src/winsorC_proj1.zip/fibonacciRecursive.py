# this module is fibonacci recursive

# as input it takes fibList and n
# fibList is the array intended to hold the fibonacci numbers
# n is the element we are currently trying to compute
# The routine updates fibList[n] by summing the recursive calls
# to calculate fibList[n-1] and fibList[n-2]
def run(fibList, n):

    length = len(fibList);

    # check for fibo(0) and fibo(1) as these are base cases
    if n == 0:
        fibList[0] = 0
        return 0
    if n == 1:
        fibList[1] = 1
        return 1

    # compute one additional element to the list
    fibList[n] = int(run(fibList,n-1)) + int(run(fibList,n-2))
    return fibList[n]
