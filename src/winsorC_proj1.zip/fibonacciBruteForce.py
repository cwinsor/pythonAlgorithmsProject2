# this module is fibonacci brute force

def run(fibList, n):
    # allocate the array

    # check for fibo(0) and fibo(1) as these are base cases
    if n == 0:
        fibList[0] = 0
        return fibList
    if n == 1:
        fibList[0] = 0
        fibList[1] = 1
        return fibList

    # loop from 2..n-1
    fibList[0] = 0
    fibList[1] = 1
    f2 = 0
    f1 = 1
    for i in range(2, n):
        fibList[i] = f2 + f1
        f2 = f1
        f1 = fibList[i]

        #array[i] = array[i-1] + array[i-2]
        #array[2] = array[0] + array[1]
    return fibList
