""" CS2223 Program 1 - fibonacci benchmark"""

# references:
# https://pymotw.com/2/timeit/
# https://docs.python.org/2/library/timeit.html

import fibonacciBruteForce
import fibonacciRecursive
import datetime


class Benchmark:

    def run(self):

        print("")
        print("Algorithms CS2223 Program 1 (fibonacci benchmark)")
        print("Chris Winsor - 5-April-2016")
        print("")

        while True:
            print("What fibonicci algorithm would you like to test?")
            print("1 -> brute force")
            print("2 -> recursive")
            print("3 -> exit")
            algorithm_choice = input("=>")
            if (algorithm_choice == "3"):
                break

            if not((algorithm_choice == "1") or (algorithm_choice == "2")):
                print("that input is invalid - try again specifying 1, 2, or 3")
            else:

                print("What values of 'n' would you like?")
                print("Enter the values as a comma delimited list")
                print("For Brute Force put in something like:")
                print("10000, 20000, 30000, 40000, 50000, 60000")
                print("For Recursive you want to stay below 30:")
                print("5,10,15,20,25,30")
                #print("10000, 20000, 30000, 40000, 50000, 60000,"
                #      "10001, 20001, 30001, 40001, 50001, 60001,"
                #      "10002, 20002, 30002, 40002, 50002, 60002      will run 8 benchmarks")
                b = input("=>")
                text = b.split(',')
                resultsArray = {}
                invalid = False
                for t in text:
                    i = int(t)
                    if i < 0:
                        invalid = True
                    else:
                        resultsArray[i] = 0

                print(str(resultsArray))

                if invalid:
                    print("that input is invalid - try again with something like 2,4,6")
                else:
                    if algorithm_choice == "1": # brute force
                        for n in resultsArray.keys():
                            print ("run brute force with n=" + str(n))

                            #allocate the dictionary
                            fibList = {}
                            for i in range(n):
                                fibList[i] = 0;

                            a = datetime.datetime.now()
                            fibonacciBruteForce.run(fibList, n)
                            b = datetime.datetime.now()
                            c = b - a
                            resultsArray[n] = c.microseconds
                            #print("zona -> " + str(fibList))


                    else:
                        for n in resultsArray.keys():
                            print("run recursive with n=" + str(n))

                            # allocate the dictionary
                            fibList = {}
                            for i in range(n):
                                fibList[i] = 0;

                            a = datetime.datetime.now()
                            result = fibonacciRecursive.run(fibList, n)
                            b = datetime.datetime.now()
                            c = b - a
                            resultsArray[n] = c.microseconds
                            #print("zona -> " + str(fibList))



                    #########################
                    # reference: https://pyformat.info/
                    print("Results are")
                    print('{0:>10.10} {1:>20.25}'.format('n','runtime(microseconds)'))
                    print('{0:>10.10} {0:>20.25}'.format('--------------------------'))
                    for n in resultsArray.keys():
                        print('{0:10d},{1:10d}'.format(n, resultsArray[n]))
                    print("")

        print("Thank you, goodbye")


Benchmark().run()
